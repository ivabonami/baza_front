import {reactive} from "vue";

export const highlightedProject = reactive([])