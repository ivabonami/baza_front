import { reactive } from 'vue'

export const productsStore = reactive({
    products: []
})