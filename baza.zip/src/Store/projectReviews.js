import { reactive } from 'vue'

export const projectReviewsStore = reactive({
    reviews: []
})