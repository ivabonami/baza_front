import {reactive} from "vue";

export const favoriteProjects = reactive([])