import {reactive, ref} from 'vue'

export const projectsStore = reactive({
    projects: []
})