import {reactive} from "vue";


export const linksCategories = reactive(
    ['Зеркало', 'Зеркало VPN', 'Контакты', 'Onion', 'Блокчейн', 'Бот', 'Канал']
)
