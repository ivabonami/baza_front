<template>

</template>

<script>
export default {
  name: "ButtonClose.vue",
  data() {
    return {}
  },

  components: {},

  methods: {},

  mounted() {

  }

}
</script>

<style scoped lang="scss">

</style>