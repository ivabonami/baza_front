<template>

</template>

<script>
export default {
  name: "ProjectsSearch.vue",
  data() {
    return {}
  },

  components: {},

  methods: {},

  mounted() {

  }

}
</script>

<style scoped lang="scss">

</style>